<?php
if(isset($_POST["submit_contact"])){
// Checking For Blank Fields..
if($_POST["contact_name"]==""||$_POST["contact_email"]==""||$_POST["contact_phone"]==""||$_POST["contact_subject"]==""){
header("location:index.php?message=Fill All Fields");
}else{
// Check if the "Sender's Email" input field is filled out
$email=$_POST['email'];
// Sanitize E-mail Address
$email =filter_var($email, FILTER_SANITIZE_EMAIL);
// Validate E-mail Address
$email= filter_var($email, FILTER_VALIDATE_EMAIL);
$subject = "Get A Free Quote";
$to      = 'info@richmonddental.in';
$contact_name = $_POST['contact_name'];
$contact_email = $_POST['contact_email'];
$contact_phone = $_POST['contact_phone'];
$contact_subject = $_POST['contact_subject'];
$contact_website = $_POST['contact_website'];
$a = $contact_name." ".$contact_email."\n".$contact_phone."\n".$contact_website."\n".$contact_subject;

$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail($to, $subject, $a, $headers);
 header("location:index.php?message=Success#next");

}
}
?>