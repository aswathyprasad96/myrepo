<?php
if(isset($_POST["submit"])){
// Checking For Blank Fields..
if($_POST["appointment_name"]==""||$_POST["appointment_date"]==""||$_POST["appointment_time"]==""||$_POST["phone"]==""){
header("location:index.php?message=Fill All Fields");
}else{
// Check if the "Sender's Email" input field is filled out
$email=$_POST['email'];
// Sanitize E-mail Address
$email =filter_var($email, FILTER_SANITIZE_EMAIL);
// Validate E-mail Address
$email= filter_var($email, FILTER_VALIDATE_EMAIL);
$subject = "New Appointments";
$to      = 'info@richmonddental.in';
$appointment_name = $_POST['appointment_name'];
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];
$appointment_email = $_POST['appointment_email'];
$phone = $_POST['phone'];
$a = $appointment_name." ".$appointment_date."\n".$appointment_time."\n".$appointment_email."\n".$phone;

$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail($to, $subject, $a, $headers);
 header("location:index.php?message=Success#next");

}
}
?>