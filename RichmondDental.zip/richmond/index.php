<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Richmond Dental Clinic</title>
    <link rel="shortcut icon" href="images/logos.png" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
    <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700" rel="stylesheet"> -->

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar" >
	    <div class="container">
	      <a class="navbar-brand" href="index.php" style="font-weight:bold !important;"><img src="images/logos.png" style="width: 13%;">Richmond <span style="font-weight:bold !important;">Dental Clinic</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation" style="color: white !important;">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto" style="display: -webkit-inline-box !important;">
	          <li class="nav-item active"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="services.html" class="nav-link">Our Services</a></li>
	          <li class="nav-item"><a href="information.html" class="nav-link">Information</a></li>
	          <li class="nav-item"><a href="patient.html" class="nav-link">Patient Education</a></li>
	          <li class="nav-item"><a href="#contact" class="nav-link">Contact Us</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image: url('images/bg_1.jpg');">
        
        <div class="overlay"></div>
        <div class="container">
          <div class="row slider-text align-items-center" data-scrollax-parent="true">
            <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
              <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">At Richmond, we are proud of our unique Brand of gentle family dentistry.
            </h1>
              <p class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">We do everything we can to make your visit comfortable or even enjoyable.</p>
            </div>
          </div>
        </div>
      </div>

      <div class="slider-item" style="background-image: url('images/back.jpg');">
        <div class="overlay"></div>
        <div class="container">
          <div class="row slider-text align-items-center" data-scrollax-parent="true">
            <div class="col-md-6 col-sm-12 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
              <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">By explaining your treatment choices every step of the way we help you make informed decision. </h1>
              <p class="mb-4">We treat you with honesty,compassion and respect.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro">
    	<div class="container">
    		<div class="row no-gutters">
    			<div class="col-md-3 color-1 p-4">
    				<h3 class="mb-4">Emergency Cases</h3>
    				<p>Dr. Hajira Nazeer</p>
    				<span class="phone-number">+91 6360743827</span>
    			</div>
    			<div class="col-md-3 color-2 p-4">
    				<h3 class="mb-4">Opening Hours</h3>
    				<p class="openinghours d-flex">
    					<span>Monday - Saturday</span>
    					<span>10 am - 09 pm</span>
    					
    				</p>
    				<p class="openinghours d-flex">
            <span>Sunday</span>
    					<span>11 am - 04 pm</span>
    				</p>
    				
    			</div>
    			<div class="col-md-6 color-3 p-4">
    				<h3 class="mb-2">Make an Appointment</h3>
    				<form id="contact-form" action="contact.php" method="post" class="appointment-form contact-form">
	            <div class="row">
	            	
	              <div class="col-sm-6">
	                <div class="form-group">
	                	<div class="icon"><span class="icon-user"></span></div>
			              <input type="text" class="form-control" id="appointment_name" name="appointment_name" placeholder="Name" required="required">
			            </div>
	              </div>
	              <div class="col-sm-6">
	                <div class="form-group">
	                	<div class="icon"><span class="icon-paper-plane"></span></div>
			              <input type="text" class="form-control" id="appointment_email" name="appointment_email" placeholder="Email">
			            </div>
	              </div>
	            </div>
	            <div class="row">
	              <div class="col-sm-4">
	                <div class="form-group">
	                	<div class="icon"><span class="ion-ios-calendar"></span></div>
	                  <input type="text" class="form-control appointment_date" name="appointment_date" placeholder="Date" required="required">
	                </div>    
	              </div>
	              <div class="col-sm-4">
	                <div class="form-group">
	                	<div class="icon"><span class="ion-ios-clock"></span></div>
	                  <input type="text" class="form-control appointment_time" name="appointment_time" placeholder="Time" required="required">
	                </div>
	              </div>
	              <div class="col-sm-4">
	                <div class="form-group">
	                	<div class="icon"><span class="icon-phone2"></span></div>
	                  <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" required="required">
	                </div>
	              </div>
	            </div>
	            
	            <div class="form-group">
	              <input type="submit" name="submit" id="submit" value="Make an Appointment" class="btn btn-primary">
	            </div>
	          </form>
    			</div>
    		</div>
    	</div>
    </section>

    
  
    <section class="ftco-section ftco-services" id="services">
      <div class="container">
      	<div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">Our Services Makes you Smile</h2>
            <p>Creating Happy And Healthy Smiles</p>
          </div>
        </div>
      

        <div class="row">
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
            <div class=" d-flex justify-content-center align-items-center">
              <img src="images/service01.jpg"  style="width: 100% !important;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Cosmetic Dentistry</h3>
                <p style="text-align: justify !important;">Cosmetic dentistry is more than just teeth whitening. Your cosmetic dentist is also capable of transforming your smile’s shape, color, alignment, as well as filling in gaps and discreetly</p>
                <a href="cosmetic.html" class="a_style">Read More . . .</a>
              </div>
            </div>      
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class=" d-flex justify-content-center align-items-center">
              <img src="images/service02.jpg"  style="width: 100% !important;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Invisalign</h3>
                <p  style="text-align: justify !important;">Invisalign is an orthodontic appliance system used to inconspicuously treat crooked and crowded teeth in adults and teens. This modern take on braces features a system of clear </p>
                <a href="invisalign.html" class="a_style">Read More . . .</a>
              </div>
            </div>    
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class=" d-flex justify-content-center align-items-center">
              <img src="images/service03.jpg" style="width: 100% !important;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">General Dentistry</h3>
                <p  style="text-align: justify !important;">General dentistry encompasses a broad range of diseases and disorders of the oral and maxillofacial region. Everyone should see a general dentist for routine oral health examinations</p>
                <a href="general.html" class="a_style">Read More . . .</a>
              </div>
            </div>    
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div class=" d-flex justify-content-center align-items-center">
              <img src="images/service04.jpg"  style="width: 100% !important;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Dental Implants</h3>
                <p  style="text-align: justify !important;">Dental implants are surgical-grade root devices that support permanent tooth prosthetics that are manufactured to last a lifetime. These artificial roots are anchored in the bone beneath the gums</p>
                <a href="dental.html" class="a_style">Read More . . .</a>
              </div>
            </div>    
          </div>
      </div>
      <div class="container-wrap mt-5" >
      	<div class="row d-flex no-gutters">
      		<div class="col-md-6 img" style="background-image: url(images/about-2.jpg);">
      		</div>
      		<div class="col-md-6 d-flex">
      			<div class="about-wrap">
      				<div class="heading-section heading-section-white mb-5 ftco-animate">
		            <h2 class="mb-2">Highest Standards Of Dental Treatment</h2>
		            <p>Richmond Dental Clinic has been independently assessed and accredited by the Indian Health Organization</p>
		          </div>
      				<div class="list-services d-flex ftco-animate">
      					<div class="icon d-flex justify-content-center align-items-center">
      						<span class="icon-check2"></span>
      					</div>
      					<div class="text">
	      					<h3>Well Experienced Dentist</h3>
	      					<p>We provide speciality based dental care in accordance to the dental needs of the patients by our internationally trained team of specialized dentists.</p>
      					</div>
      				</div>
      				<div class="list-services d-flex ftco-animate">
      					<div class="icon d-flex justify-content-center align-items-center">
      						<span class="icon-check2"></span>
      					</div>
      					<div class="text">
	      					<h3>High Standards of Sterilization</h3>
	      					<p>We take the utmost care to ensure sterilization of instruments and equipment to safeguard our patients.</p>
      					</div>
      				</div>
      				<div class="list-services d-flex ftco-animate">
      					<div class="icon d-flex justify-content-center align-items-center">
      						<span class="icon-check2"></span>
      					</div>
      					<div class="text">
	      					<h3>Comfortable Clinics</h3>
	      					<p>We provide transparent treatment charges.We constantly upgrade our services, techniques and equipment on a regular basis to provide you the latest and best dental treatment in every sphere from digital radiographs to laser dentistry.</p>
      					</div>
      				</div>
      			</div>
      		</div>
      	</div>
      </div>
</section>
		<br><br>
		
		<section class="ftco-quote" id="contact">
    	<div class="container">
    		<div class="row">
    			<div class="col-md-6">
    			<div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.1668896770657!2d77.5973671143043!3d12.961170518615168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15d128cb8ad7%3A0x5e9cad75939f3738!2sRP%20Building%2C%20Langford%20Rd%2C%20Akkithimana%20Halli%2C%20Bheemanna%20Garden%2C%20Shanti%20Nagar%2C%20Bengaluru%2C%20Karnataka%20560027!5e0!3m2!1sen!2sin!4v1571058977810!5m2!1sen!2sin" width="100%" height="450px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </div>
	          
    			</div>
    			<div class="col-md-6">
    				<div class="heading-section ftco-animate">
	            <h2 class="mb-2" style="padding: 5px;">Get a Free Quote</h2>
	          </div>

	          <form id="get-quote-form" action="quote.php" method="post" class="ftco-animate quote-form">
	          	<div class="row">
	          		<div class="col-md-6">
		              <div class="form-group">
		                <input type="text" name="contact_name" class="form-control" placeholder="Full Name" required="required">
		              </div>
	              </div>
	              <div class="col-md-6">
		              <div class="form-group">
		                <input type="text" class="form-control" name="contact_email" placeholder="Email" required="required">
		              </div>
	              </div>
	              <div class="col-md-6">
	              	<div class="form-group">
		                <input type="text" name="contact_phone" class="form-control" placeholder="Phone" required="required">
		              </div>
		            </div>
	              <div class="col-md-6">
	              	<div class="form-group">
		                <input type="text" name="contact_website" class="form-control" placeholder="Website">
		              </div>
		            </div>
		            <div class="col-md-12">
		              <div class="form-group">
		                <textarea name="contact_subject" id="" cols="30" rows="7" class="form-control" placeholder="Message" required="required"></textarea>
		              </div>
		            </div>
		            <div class="col-md-12" style="display: flex;justify-content: center;">
		              <div class="form-group">
		                <input type="submit" name="submit_contact" value="Get a Quote" class="btn btn-primary py-3 px-5">
		              </div>
	              </div>
              </div>
            </form>
    			</div>
    		</div>
    	</div>
    </section>
		
		

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Richmond Dental Clinic.</h2>
              <p>We are here to provide affordable dental care to the families in our community.</p>
            </div>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft ">
              <li class="ftco-animate"><a href="https://www.facebook.com/drhajira.sheriff" target="_blank"><span class="icon-facebook"></span></a></li>
            </ul>
          </div>
         
          
          <div class="col-md-4">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Office</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Clinic No:543, RP Building, Langford Road, Oppo. Karnataka Hockey Stadium, Banglore - 560027</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+91 6360743827</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@richmonddental.in</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

  <!-- Modal -->
  <div class="modal fade" id="modalRequest" tabindex="-1" role="dialog" aria-labelledby="modalRequestLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalRequestLabel">Make an Appointment</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="#">
            <div class="form-group">
              <!-- <label for="appointment_name" class="text-black">Full Name</label> -->
              <input type="text" class="form-control" id="appointment_name" placeholder="Full Name">
            </div>
            <div class="form-group">
              <!-- <label for="appointment_email" class="text-black">Email</label> -->
              <input type="text" class="form-control" id="appointment_email" placeholder="Email">
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <!-- <label for="appointment_date" class="text-black">Date</label> -->
                  <input type="text" class="form-control appointment_date" placeholder="Date">
                </div>    
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <!-- <label for="appointment_time" class="text-black">Time</label> -->
                  <input type="text" class="form-control appointment_time" placeholder="Time">
                </div>
              </div>
            </div>
            

            <div class="form-group">
              <!-- <label for="appointment_message" class="text-black">Message</label> -->
              <textarea name="" id="appointment_message" class="form-control" cols="30" rows="10" placeholder="Message"></textarea>
            </div>
            <div class="form-group">
              <input type="submit" value="Make an Appointment" class="btn btn-primary">
            </div>
          </form>
        </div>
        
      </div>
    </div>
  </div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
<script>
</script>
  </body>
</html>